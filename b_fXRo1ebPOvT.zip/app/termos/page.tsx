import type { Metadata } from "next"
import { TermsPage } from "@/components/terms/TermsPage"

export const metadata: Metadata = {
  title: "Termos de Uso — CurrIA",
  description:
    "Leia os Termos de Uso da plataforma CurrIA antes de utilizar nossos serviços de geração e otimização de currículos com inteligência artificial.",
}

export default function Page() {
  return <TermsPage />
}
