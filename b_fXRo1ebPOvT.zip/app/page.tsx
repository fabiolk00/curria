import Link from "next/link"
import { ResumeResultPage } from "@/components/resume/ResumeResultPage"

export default function Page() {
  return (
    <>
      <ResumeResultPage />
      <div className="fixed bottom-4 left-4 z-50">
        <Link
          href="/termos"
          className="text-xs text-muted-foreground hover:text-foreground underline underline-offset-2 transition-colors"
        >
          Termos de Uso
        </Link>
      </div>
    </>
  )
}
