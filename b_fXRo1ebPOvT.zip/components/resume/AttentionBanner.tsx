import { AlertTriangle } from "lucide-react"

interface AttentionBannerProps {
  count: number
}

export function AttentionBanner({ count }: AttentionBannerProps) {
  if (count === 0) return null

  return (
    <div className="bg-amber-50 border-b border-amber-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2.5 flex items-center gap-2.5">
        <AlertTriangle className="size-3.5 text-amber-600 shrink-0" />
        <p className="text-sm text-amber-800">
          Este currículo foi gerado com{" "}
          <span className="font-medium">
            {count} {count === 1 ? "ponto de atenção" : "pontos de atenção"}
          </span>
          . Revise os itens na barra lateral antes de enviar.
        </p>
      </div>
    </div>
  )
}
