"use client"

import { useState } from "react"
import {
  ChevronDown,
  ChevronRight,
  AlertTriangle,
  XCircle,
  Eye,
  XOctagon,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible"
import { cn } from "@/lib/utils"
import type {
  AttentionPoint,
  AdherenceSuggestion,
  AttentionSeverity,
  ScoreBreakdown,
} from "./types"

// ─── Score Breakdown Card ────────────────────────────────────────────────────

function ScoreBar({ score, max }: { score: number; max: number }) {
  const pct = Math.round((score / max) * 100)
  // Color tiers: ≥90% green, ≥70% amber, <70% red
  const color =
    pct >= 90
      ? "bg-emerald-500"
      : pct >= 70
        ? "bg-amber-400"
        : "bg-red-400"

  return (
    <div className="h-2 w-full rounded-full bg-zinc-100 overflow-hidden">
      <div
        className={cn("h-full rounded-full transition-all duration-500", color)}
        style={{ width: `${pct}%` }}
      />
    </div>
  )
}

function ScoreBreakdownCard({ breakdown }: { breakdown: ScoreBreakdown }) {
  const totalPct = Math.round((breakdown.total / breakdown.maxTotal) * 100)
  const totalColor =
    totalPct >= 90
      ? "text-emerald-600"
      : totalPct >= 70
        ? "text-amber-600"
        : "text-red-500"

  return (
    <div className="rounded-xl border border-zinc-200 bg-white overflow-hidden">
      {/* Header */}
      <div className="px-4 pt-4 pb-3 flex items-center justify-between">
        <p className="text-sm font-semibold text-zinc-900">Composição da Nota</p>
        <span className={cn("text-sm font-bold tabular-nums", totalColor)}>
          {breakdown.total}
          <span className="text-xs font-medium text-zinc-400">
            /{breakdown.maxTotal}
          </span>
        </span>
      </div>

      {/* Score rows */}
      <div className="px-4 pb-4 flex flex-col gap-3">
        {breakdown.items.map((item) => (
          <div key={item.label} className="flex flex-col gap-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs text-zinc-600">{item.label}</span>
              <span className="text-xs font-semibold tabular-nums text-zinc-700">
                {item.score}
                <span className="font-normal text-zinc-400">/{item.max}</span>
              </span>
            </div>
            <ScoreBar score={item.score} max={item.max} />
          </div>
        ))}
      </div>

      {/* Critical Gaps */}
      {breakdown.criticalGaps.length > 0 && (
        <>
          <div className="border-t border-zinc-100 mx-0" />
          <div className="px-4 py-3 flex flex-col gap-2">
            <p className="text-[10px] font-semibold uppercase tracking-widest text-zinc-400">
              Gaps Críticos
            </p>
            <ul className="flex flex-col gap-2">
              {breakdown.criticalGaps.map((gap, i) => (
                <li key={i} className="flex items-start gap-2">
                  <XOctagon className="size-3.5 text-red-500 mt-0.5 shrink-0" />
                  <span className="text-xs text-zinc-600 leading-relaxed">
                    {gap}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </>
      )}
    </div>
  )
}

// ─── Attention Points ────────────────────────────────────────────────────────

const SEVERITY_CONFIG: Record<
  AttentionSeverity,
  { label: string; icon: React.ReactNode; borderColor: string; badge: string }
> = {
  review: {
    label: "Revisar",
    icon: <Eye className="size-3.5 text-zinc-400" />,
    borderColor: "border-zinc-200",
    badge: "border-zinc-300 text-zinc-600 bg-zinc-50",
  },
  warning: {
    label: "Atenção",
    icon: <AlertTriangle className="size-3.5 text-amber-500" />,
    borderColor: "border-amber-200",
    badge: "border-amber-200 text-amber-700 bg-amber-50",
  },
  error: {
    label: "Risco",
    icon: <XCircle className="size-3.5 text-red-500" />,
    borderColor: "border-red-200",
    badge: "border-red-200 text-red-700 bg-red-50",
  },
}

function AttentionCard({ point }: { point: AttentionPoint }) {
  const [open, setOpen] = useState(false)
  const config = SEVERITY_CONFIG[point.severity]

  return (
    <div
      className={cn(
        "rounded-lg border bg-white p-3 space-y-1.5",
        config.borderColor,
      )}
    >
      <div className="flex items-start gap-2">
        <span className="mt-0.5 shrink-0">{config.icon}</span>
        <div className="flex-1 min-w-0">
          <span
            className={cn(
              "inline-flex items-center rounded border px-1.5 py-0.5 text-[11px] font-medium",
              config.badge,
            )}
          >
            {config.label}
          </span>
          <p className="text-sm font-medium text-zinc-900 mt-1 leading-snug">
            {point.title}
          </p>
          <p className="text-xs text-zinc-500 mt-0.5 leading-relaxed">
            {point.description}
          </p>
        </div>
      </div>

      {point.detail && (
        <Collapsible open={open} onOpenChange={setOpen}>
          <CollapsibleTrigger asChild>
            <button className="flex items-center gap-1 text-xs text-zinc-400 hover:text-zinc-700 transition-colors mt-1">
              {open ? (
                <ChevronDown className="size-3" />
              ) : (
                <ChevronRight className="size-3" />
              )}
              {open ? "Ocultar detalhe" : "Ver detalhe"}
            </button>
          </CollapsibleTrigger>
          <CollapsibleContent>
            <p className="text-xs text-zinc-600 bg-zinc-50 rounded p-2 mt-1 leading-relaxed border border-zinc-100">
              {point.detail}
            </p>
          </CollapsibleContent>
        </Collapsible>
      )}
    </div>
  )
}

// ─── Adherence Suggestions ───────────────────────────────────────────────────

const PRIORITY_BADGE: Record<"Alta" | "Média" | "Baixa", string> = {
  Alta: "border-red-200 text-red-700 bg-red-50",
  Média: "border-amber-200 text-amber-700 bg-amber-50",
  Baixa: "border-zinc-200 text-zinc-600 bg-zinc-50",
}

function AdherenceCard({ suggestion }: { suggestion: AdherenceSuggestion }) {
  const [open, setOpen] = useState(false)

  return (
    <div className="rounded-lg border border-zinc-200 bg-white p-3 space-y-1.5">
      <div className="flex items-start justify-between gap-2">
        <p className="text-sm font-medium text-zinc-900 leading-snug">
          {suggestion.title}
        </p>
        <span
          className={cn(
            "inline-flex items-center rounded border px-1.5 py-0.5 text-[11px] font-medium shrink-0",
            PRIORITY_BADGE[suggestion.priority],
          )}
        >
          {suggestion.priority}
        </span>
      </div>
      <p className="text-xs text-zinc-500 leading-relaxed">
        {suggestion.description}
      </p>

      {suggestion.example && (
        <Collapsible open={open} onOpenChange={setOpen}>
          <CollapsibleTrigger asChild>
            <button className="flex items-center gap-1 text-xs text-zinc-400 hover:text-zinc-700 transition-colors">
              {open ? (
                <ChevronDown className="size-3" />
              ) : (
                <ChevronRight className="size-3" />
              )}
              {open ? "Ocultar exemplo" : "Ver exemplo"}
            </button>
          </CollapsibleTrigger>
          <CollapsibleContent>
            <p className="text-xs text-zinc-600 bg-zinc-50 rounded p-2 mt-1 leading-relaxed border border-zinc-100 italic">
              {suggestion.example}
            </p>
          </CollapsibleContent>
        </Collapsible>
      )}
    </div>
  )
}

// ─── ReviewSidebar ───────────────────────────────────────────────────────────

interface ReviewSidebarProps {
  attentionPoints: AttentionPoint[]
  adherenceSuggestions: AdherenceSuggestion[]
  scoreBreakdown?: ScoreBreakdown
}

const INITIAL_SUGGESTIONS_SHOWN = 3

export function ReviewSidebar({
  attentionPoints,
  adherenceSuggestions,
  scoreBreakdown,
}: ReviewSidebarProps) {
  const [showAllSuggestions, setShowAllSuggestions] = useState(false)

  const hasAttention = attentionPoints.length > 0
  const hasAdherence = adherenceSuggestions.length > 0
  const visibleSuggestions = showAllSuggestions
    ? adherenceSuggestions
    : adherenceSuggestions.slice(0, INITIAL_SUGGESTIONS_SHOWN)
  const hiddenCount = adherenceSuggestions.length - INITIAL_SUGGESTIONS_SHOWN

  return (
    <aside className="flex flex-col gap-5">
      {/* Score Breakdown */}
      {scoreBreakdown && <ScoreBreakdownCard breakdown={scoreBreakdown} />}

      {/* Attention Points */}
      {hasAttention && (
        <div className="flex flex-col gap-2.5">
          <p className="text-xs font-semibold uppercase tracking-widest text-zinc-400">
            Pontos para revisar
          </p>
          <div className="flex flex-col gap-2">
            {attentionPoints.map((point) => (
              <AttentionCard key={point.id} point={point} />
            ))}
          </div>
        </div>
      )}

      {hasAttention && hasAdherence && (
        <Separator className="bg-zinc-100" />
      )}

      {/* Adherence Suggestions */}
      {hasAdherence && (
        <div className="flex flex-col gap-2.5">
          <div>
            <p className="text-xs font-semibold uppercase tracking-widest text-zinc-400">
              Sugestões de aderência
            </p>
            <p className="text-xs text-zinc-400 mt-1">
              Adicione apenas informações verdadeiras.
            </p>
          </div>
          <div className="flex flex-col gap-2">
            {visibleSuggestions.map((s) => (
              <AdherenceCard key={s.id} suggestion={s} />
            ))}
          </div>
          {!showAllSuggestions && hiddenCount > 0 && (
            <Button
              variant="outline"
              size="sm"
              className="w-full text-zinc-500 border-zinc-200 hover:bg-zinc-50 text-xs h-8"
              onClick={() => setShowAllSuggestions(true)}
            >
              Ver todas ({hiddenCount} restantes)
            </Button>
          )}
          {showAllSuggestions &&
            adherenceSuggestions.length > INITIAL_SUGGESTIONS_SHOWN && (
              <Button
                variant="ghost"
                size="sm"
                className="w-full text-zinc-400 text-xs h-8"
                onClick={() => setShowAllSuggestions(false)}
              >
                Mostrar menos
              </Button>
            )}
        </div>
      )}
    </aside>
  )
}
