"use client"

import { cn } from "@/lib/utils"

interface ResumeSection {
  id: string
  title: string
  changed?: boolean
  content: React.ReactNode
}

interface ResumePreviewCardProps {
  className?: string
  highlightChanges?: boolean
}

const resumeSections: ResumeSection[] = [
  {
    id: "header",
    title: "Cabeçalho",
    changed: false,
    content: (
      <div className="text-center pb-5 border-b border-border">
        <h1 className="text-2xl font-bold tracking-tight text-foreground">Ana Carolina Mendes</h1>
        <p className="text-sm text-muted-foreground mt-1">
          São Paulo, SP · ana.mendes@email.com · (11) 99999-8888 · linkedin.com/in/anacarolina
        </p>
      </div>
    ),
  },
  {
    id: "summary",
    title: "Resumo profissional",
    changed: true,
    content: (
      <div>
        <h2 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-2">
          Resumo Profissional
        </h2>
        <p className="text-sm text-foreground leading-relaxed">
          Engenheira de Software com 6 anos de experiência em desenvolvimento de produtos SaaS de alta escala. 
          Especialista em arquiteturas orientadas a eventos, APIs RESTful e microsserviços com foco em 
          performance e confiabilidade. Forte histórico em liderar migrações técnicas e melhorias de 
          observabilidade em ambientes cloud-native (AWS, GCP).
        </p>
      </div>
    ),
  },
  {
    id: "experience",
    title: "Experiência",
    changed: true,
    content: (
      <div>
        <h2 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-3">
          Experiência Profissional
        </h2>
        <div className="space-y-4">
          <div>
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-semibold text-foreground">Engenheira de Software Sênior</p>
                <p className="text-sm text-muted-foreground">Nubank · São Paulo, SP</p>
              </div>
              <span className="text-xs text-muted-foreground whitespace-nowrap ml-4">Jan 2021 – Presente</span>
            </div>
            <ul className="mt-2 space-y-1 list-disc list-inside text-sm text-foreground leading-relaxed">
              <li>Liderou a migração de monolito para microsserviços, reduzindo latência em 40%</li>
              <li>Implementou sistema de observabilidade com OpenTelemetry e Datadog para 30+ serviços</li>
              <li>Conduziu revisões de arquitetura e mentoria de 4 engenheiros júnior</li>
            </ul>
          </div>
          <div>
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-semibold text-foreground">Engenheira de Software Pleno</p>
                <p className="text-sm text-muted-foreground">Totvs · São Paulo, SP</p>
              </div>
              <span className="text-xs text-muted-foreground whitespace-nowrap ml-4">Mar 2019 – Dez 2020</span>
            </div>
            <ul className="mt-2 space-y-1 list-disc list-inside text-sm text-foreground leading-relaxed">
              <li>Desenvolveu APIs de integração com ERPs utilizando Java e Spring Boot</li>
              <li>Reduziu o tempo de onboarding de novos clientes em 25% com automações internas</li>
            </ul>
          </div>
        </div>
      </div>
    ),
  },
  {
    id: "skills",
    title: "Skills",
    changed: true,
    content: (
      <div>
        <h2 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-3">
          Habilidades Técnicas
        </h2>
        <div className="grid grid-cols-2 gap-3 text-sm">
          <div>
            <p className="font-medium text-foreground mb-1">Linguagens</p>
            <p className="text-muted-foreground">Go, Python, TypeScript, Java</p>
          </div>
          <div>
            <p className="font-medium text-foreground mb-1">Cloud & Infra</p>
            <p className="text-muted-foreground">AWS (ECS, Lambda, RDS), GCP, Terraform</p>
          </div>
          <div>
            <p className="font-medium text-foreground mb-1">Observabilidade</p>
            <p className="text-muted-foreground">OpenTelemetry, Datadog, Prometheus</p>
          </div>
          <div>
            <p className="font-medium text-foreground mb-1">Dados & Mensageria</p>
            <p className="text-muted-foreground">Kafka, PostgreSQL, Redis, BigQuery</p>
          </div>
        </div>
      </div>
    ),
  },
  {
    id: "education",
    title: "Educação",
    changed: false,
    content: (
      <div>
        <h2 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-2">
          Educação
        </h2>
        <div className="flex items-start justify-between">
          <div>
            <p className="text-sm font-semibold text-foreground">Bacharelado em Ciência da Computação</p>
            <p className="text-sm text-muted-foreground">Universidade de São Paulo (USP)</p>
          </div>
          <span className="text-xs text-muted-foreground whitespace-nowrap ml-4">2014 – 2018</span>
        </div>
      </div>
    ),
  },
  {
    id: "certifications",
    title: "Certificações",
    changed: false,
    content: (
      <div>
        <h2 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-2">
          Certificações
        </h2>
        <ul className="text-sm text-foreground space-y-1">
          <li className="flex justify-between">
            <span>AWS Certified Solutions Architect – Associate</span>
            <span className="text-muted-foreground">2022</span>
          </li>
          <li className="flex justify-between">
            <span>Google Cloud Professional Data Engineer</span>
            <span className="text-muted-foreground">2023</span>
          </li>
        </ul>
      </div>
    ),
  },
]

export function ResumePreviewCard({ className, highlightChanges = true }: ResumePreviewCardProps) {
  return (
    <div
      className={cn(
        "bg-card border border-border rounded-xl shadow-sm overflow-hidden",
        className
      )}
    >
      {/* Document chrome */}
      <div className="flex items-center gap-1.5 px-4 py-3 border-b border-border bg-secondary/60">
        <div className="w-2.5 h-2.5 rounded-full bg-border" />
        <div className="w-2.5 h-2.5 rounded-full bg-border" />
        <div className="w-2.5 h-2.5 rounded-full bg-border" />
        <span className="ml-3 text-xs text-muted-foreground font-mono">curriculo_otimizado.pdf</span>
        {highlightChanges && (
          <span className="ml-auto text-xs text-muted-foreground">
            <span className="inline-block w-2 h-2 rounded-sm bg-amber-200 border border-amber-400 mr-1" />
            seções alteradas
          </span>
        )}
      </div>

      {/* Resume content */}
      <div className="p-10 max-w-2xl mx-auto">
        <div className="space-y-6">
          {resumeSections.map((section) => (
            <div
              key={section.id}
              id={`section-${section.id}`}
              className={cn(
                "rounded-lg transition-colors",
                highlightChanges && section.changed
                  ? "bg-amber-50 border border-amber-200 px-4 py-3 -mx-4"
                  : ""
              )}
            >
              {section.content}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
