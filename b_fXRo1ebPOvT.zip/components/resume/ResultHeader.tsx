"use client"

import { ArrowLeft, Download, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import type { FlowType } from "./types"

interface ResultHeaderProps {
  flow: FlowType
  jobTitle?: string
  companyName?: string
  isDownloadAvailable?: boolean
  isDownloadLoading?: boolean
  isPreviewLocked?: boolean
  onBack: () => void
  onDownload: () => void
}

export function ResultHeader({
  flow,
  jobTitle,
  companyName,
  isDownloadAvailable = true,
  isDownloadLoading = false,
  isPreviewLocked = false,
  onBack,
  onDownload,
}: ResultHeaderProps) {
  const isJobTargeting = flow === "job-targeting"

  const title = isJobTargeting
    ? "Currículo adaptado para a vaga"
    : "Currículo otimizado para ATS"

  const subtitle = isJobTargeting
    ? jobTitle && companyName
      ? `${jobTitle} · ${companyName}`
      : "Revise o currículo gerado e os pontos de aderência"
    : "Revise as melhorias aplicadas para sistemas de triagem"

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-zinc-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-4">
        {/* Left: logo + title */}
        <div className="flex items-center gap-4 min-w-0">
          <span className="text-sm font-semibold tracking-tight text-zinc-900 shrink-0">
            CurrIA
          </span>
          <div className="hidden sm:block w-px h-4 bg-zinc-200 shrink-0" />
          <div className="hidden sm:block min-w-0">
            <p className="text-sm font-medium text-zinc-900 truncate leading-tight">
              {title}
            </p>
            {subtitle && (
              <p className="text-xs text-zinc-500 truncate leading-tight">
                {subtitle}
              </p>
            )}
          </div>
        </div>

        {/* Right: actions */}
        <div className="flex items-center gap-2 shrink-0">
          <Button
            variant="outline"
            size="sm"
            onClick={onBack}
            className="gap-1.5 text-zinc-700 border-zinc-200 hover:bg-zinc-50"
          >
            <ArrowLeft className="size-3.5" />
            <span className="hidden sm:inline">Voltar ao Perfil</span>
            <span className="sm:hidden">Voltar</span>
          </Button>

          {!isPreviewLocked && (
            <Button
              size="sm"
              onClick={onDownload}
              disabled={!isDownloadAvailable || isDownloadLoading}
              className="gap-1.5"
            >
              {isDownloadLoading ? (
                <Loader2 className="size-3.5 animate-spin" />
              ) : (
                <Download className="size-3.5" />
              )}
              <span className="hidden sm:inline">Baixar PDF</span>
              <span className="sm:hidden">PDF</span>
            </Button>
          )}
        </div>
      </div>

      {/* Mobile title row */}
      <div className="sm:hidden px-4 pb-2">
        <p className="text-sm font-medium text-zinc-900 leading-tight">{title}</p>
        {subtitle && (
          <p className="text-xs text-zinc-500 leading-tight">{subtitle}</p>
        )}
      </div>
    </header>
  )
}
