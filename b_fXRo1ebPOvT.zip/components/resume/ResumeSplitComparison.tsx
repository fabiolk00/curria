"use client"

import { useState } from "react"
import { ResumePreviewCard } from "./ResumePreviewCard"
import { OriginalResumePreviewCard } from "./OriginalResumePreviewCard"
import { cn } from "@/lib/utils"

interface ResumeSplitComparisonProps {
  className?: string
}

export function ResumeSplitComparison({ className }: ResumeSplitComparisonProps) {
  const [activeTab, setActiveTab] = useState<"original" | "otimizado">("original")

  return (
    <div className={cn("w-full", className)}>
      {/* Mobile: tab switcher */}
      <div className="flex md:hidden w-full border border-border rounded-lg overflow-hidden mb-4">
        <button
          onClick={() => setActiveTab("original")}
          className={cn(
            "flex-1 py-2.5 text-sm font-medium transition-colors",
            activeTab === "original"
              ? "bg-foreground text-primary-foreground"
              : "bg-card text-muted-foreground hover:text-foreground"
          )}
        >
          Original
        </button>
        <button
          onClick={() => setActiveTab("otimizado")}
          className={cn(
            "flex-1 py-2.5 text-sm font-medium transition-colors border-l border-border",
            activeTab === "otimizado"
              ? "bg-foreground text-primary-foreground"
              : "bg-card text-muted-foreground hover:text-foreground"
          )}
        >
          Otimizado
        </button>
      </div>

      {/* Mobile: single card view */}
      <div className="md:hidden">
        {activeTab === "original" ? (
          <OriginalResumePreviewCard />
        ) : (
          <ResumePreviewCard highlightChanges={false} />
        )}
      </div>

      {/* Desktop: side-by-side */}
      <div className="hidden md:grid md:grid-cols-2 gap-5">
        <div>
          <div className="flex items-center gap-2 mb-3">
            <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
              Currículo original
            </span>
          </div>
          <OriginalResumePreviewCard />
        </div>
        <div>
          <div className="flex items-center gap-2 mb-3">
            <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
              Currículo otimizado
            </span>
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-50 border border-amber-200 text-xs text-amber-700 font-medium">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
              alterado
            </span>
          </div>
          <ResumePreviewCard highlightChanges={true} />
        </div>
      </div>
    </div>
  )
}
