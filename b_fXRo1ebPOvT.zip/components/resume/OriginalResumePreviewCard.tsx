"use client"

import { cn } from "@/lib/utils"

interface OriginalResumePreviewCardProps {
  className?: string
}

export function OriginalResumePreviewCard({ className }: OriginalResumePreviewCardProps) {
  return (
    <div
      className={cn(
        "bg-card border border-border rounded-xl shadow-sm overflow-hidden",
        className
      )}
    >
      {/* Document chrome */}
      <div className="flex items-center gap-1.5 px-4 py-3 border-b border-border bg-secondary/60">
        <div className="w-2.5 h-2.5 rounded-full bg-border" />
        <div className="w-2.5 h-2.5 rounded-full bg-border" />
        <div className="w-2.5 h-2.5 rounded-full bg-border" />
        <span className="ml-3 text-xs text-muted-foreground font-mono">curriculo_original.pdf</span>
      </div>

      {/* Resume content */}
      <div className="p-10 max-w-2xl mx-auto">
        <div className="space-y-6">
          {/* Header */}
          <div className="text-center pb-5 border-b border-border">
            <h1 className="text-2xl font-bold tracking-tight text-foreground">Ana Carolina Mendes</h1>
            <p className="text-sm text-muted-foreground mt-1">
              São Paulo, SP · ana.mendes@email.com · (11) 99999-8888 · linkedin.com/in/anacarolina
            </p>
          </div>

          {/* Summary – original, less targeted */}
          <div>
            <h2 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-2">
              Resumo Profissional
            </h2>
            <p className="text-sm text-foreground leading-relaxed">
              Engenheira de Software com 6 anos de experiência em desenvolvimento web e backend. 
              Experiência com diversas linguagens e frameworks. Boa comunicação e trabalho em equipe. 
              Interesse em desafios técnicos e crescimento profissional.
            </p>
          </div>

          {/* Experience */}
          <div>
            <h2 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-3">
              Experiência Profissional
            </h2>
            <div className="space-y-4">
              <div>
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm font-semibold text-foreground">Engenheira de Software Sênior</p>
                    <p className="text-sm text-muted-foreground">Nubank · São Paulo, SP</p>
                  </div>
                  <span className="text-xs text-muted-foreground whitespace-nowrap ml-4">Jan 2021 – Presente</span>
                </div>
                <ul className="mt-2 space-y-1 list-disc list-inside text-sm text-foreground leading-relaxed">
                  <li>Trabalhei no desenvolvimento e manutenção de sistemas internos</li>
                  <li>Participei de projetos de refatoração de código legado</li>
                  <li>Auxiliei na integração de novos membros no time</li>
                </ul>
              </div>
              <div>
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm font-semibold text-foreground">Engenheira de Software Pleno</p>
                    <p className="text-sm text-muted-foreground">Totvs · São Paulo, SP</p>
                  </div>
                  <span className="text-xs text-muted-foreground whitespace-nowrap ml-4">Mar 2019 – Dez 2020</span>
                </div>
                <ul className="mt-2 space-y-1 list-disc list-inside text-sm text-foreground leading-relaxed">
                  <li>Desenvolveu APIs de integração com ERPs utilizando Java e Spring Boot</li>
                  <li>Colaborou com times de produto e design</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Skills – original, less specific */}
          <div>
            <h2 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-3">
              Habilidades Técnicas
            </h2>
            <p className="text-sm text-foreground leading-relaxed">
              Python, JavaScript, Java, SQL, Git, Docker, AWS (básico), REST APIs
            </p>
          </div>

          {/* Education */}
          <div>
            <h2 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-2">
              Educação
            </h2>
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-semibold text-foreground">Bacharelado em Ciência da Computação</p>
                <p className="text-sm text-muted-foreground">Universidade de São Paulo (USP)</p>
              </div>
              <span className="text-xs text-muted-foreground whitespace-nowrap ml-4">2014 – 2018</span>
            </div>
          </div>

          {/* Certifications */}
          <div>
            <h2 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-2">
              Certificações
            </h2>
            <ul className="text-sm text-foreground space-y-1">
              <li className="flex justify-between">
                <span>AWS Certified Solutions Architect – Associate</span>
                <span className="text-muted-foreground">2022</span>
              </li>
              <li className="flex justify-between">
                <span>Google Cloud Professional Data Engineer</span>
                <span className="text-muted-foreground">2023</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}
