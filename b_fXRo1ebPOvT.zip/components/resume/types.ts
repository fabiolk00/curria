export type FlowType = "job-targeting" | "ats-enhancement"

export interface ScoreBreakdownItem {
  label: string
  score: number
  max: number
}

export interface ScoreBreakdown {
  total: number
  maxTotal: number
  items: ScoreBreakdownItem[]
  criticalGaps: string[]
}

export type AttentionSeverity = "review" | "warning" | "error"

export interface AttentionPoint {
  id: string
  severity: AttentionSeverity
  title: string
  description: string
  detail?: string
}

export interface AdherenceSuggestion {
  id: string
  priority: "Alta" | "Média" | "Baixa"
  title: string
  description: string
  example?: string
}

export interface ResumeSection {
  id: string
  title: string
  content: string
  isHighlighted?: boolean
}

export interface ResumeData {
  candidateName: string
  jobTitle?: string
  companyName?: string
  sections: ResumeSection[]
}

export interface ResumeResultData {
  flow: FlowType
  generated: ResumeData
  original?: ResumeData
  attentionPoints: AttentionPoint[]
  adherenceSuggestions: AdherenceSuggestion[]
  scoreBreakdown?: ScoreBreakdown
  isPreviewLocked?: boolean
  isDownloadLoading?: boolean
  isDownloadAvailable?: boolean
}
