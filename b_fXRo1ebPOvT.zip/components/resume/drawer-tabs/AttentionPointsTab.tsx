"use client"

import { AlertTriangle, Info, XCircle } from "lucide-react"
import { cn } from "@/lib/utils"

type Severity = "alta" | "média" | "baixa"

interface Warning {
  id: string
  severity: Severity
  title: string
  explanation: string
  action: string
}

const warnings: Warning[] = [
  {
    id: "w1",
    severity: "alta",
    title: "Afirmação sem evidência",
    explanation:
      "O resumo menciona \"liderança de migrações técnicas\", mas nenhuma experiência detalha resultado concreto dessa migração.",
    action: "Adicione um bullet com o resultado da migração (ex: redução de 40% na latência).",
  },
  {
    id: "w2",
    severity: "média",
    title: "Seniority mismatch",
    explanation:
      "A vaga exige experiência com Staff Engineer ou Tech Lead. Seu currículo original não demonstra responsabilidades de liderança técnica clara.",
    action: "Inclua exemplos de decisões de arquitetura tomadas de forma autônoma.",
  },
  {
    id: "w3",
    severity: "média",
    title: "Skill não comprovada",
    explanation:
      "Go foi adicionado ao currículo, mas não aparece em nenhuma experiência profissional detalhada.",
    action: "Mencione algum projeto interno ou side project que usou Go, ou remova da lista de skills.",
  },
  {
    id: "w4",
    severity: "baixa",
    title: "Data de certificação ausente",
    explanation:
      "Certificações sem data podem levantar dúvidas sobre validade e atualidade.",
    action: "Confirme e adicione o ano de emissão de cada certificação.",
  },
]

const severityConfig: Record<
  Severity,
  { label: string; icon: React.ElementType; bg: string; border: string; text: string; badge: string }
> = {
  alta: {
    label: "Alta",
    icon: XCircle,
    bg: "bg-red-50",
    border: "border-red-200",
    text: "text-red-800",
    badge: "bg-red-100 text-red-700 border-red-200",
  },
  média: {
    label: "Média",
    icon: AlertTriangle,
    bg: "bg-amber-50",
    border: "border-amber-200",
    text: "text-amber-800",
    badge: "bg-amber-100 text-amber-700 border-amber-200",
  },
  baixa: {
    label: "Baixa",
    icon: Info,
    bg: "bg-blue-50",
    border: "border-blue-200",
    text: "text-blue-800",
    badge: "bg-blue-100 text-blue-700 border-blue-200",
  },
}

export function AttentionPointsTab() {
  return (
    <div className="space-y-3">
      <p className="text-xs text-muted-foreground leading-relaxed">
        Pontos que podem gerar dúvidas no recrutador. Revise antes de enviar.
      </p>
      {warnings.map((w) => {
        const cfg = severityConfig[w.severity]
        const Icon = cfg.icon
        return (
          <div
            key={w.id}
            className={cn(
              "rounded-lg border p-4 space-y-2.5",
              cfg.bg,
              cfg.border
            )}
          >
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Icon className={cn("w-4 h-4 shrink-0", cfg.text)} />
                <p className={cn("text-sm font-semibold", cfg.text)}>{w.title}</p>
              </div>
              <span
                className={cn(
                  "text-[11px] font-semibold px-2 py-0.5 rounded-full border",
                  cfg.badge
                )}
              >
                {cfg.label}
              </span>
            </div>
            <p className="text-xs text-foreground leading-relaxed">{w.explanation}</p>
            <div className="pt-1 border-t border-current/10">
              <p className="text-xs font-medium text-muted-foreground">Sugestão:</p>
              <p className="text-xs text-foreground mt-0.5">{w.action}</p>
            </div>
          </div>
        )
      })}
    </div>
  )
}
