"use client"

import { ArrowUpRight, Eye } from "lucide-react"
import { cn } from "@/lib/utils"

interface Change {
  id: string
  section: string
  description: string
  sectionId: string
}

const changes: Change[] = [
  {
    id: "c1",
    section: "Resumo profissional",
    description:
      "Reescrito para destacar expertise em plataforma, arquiteturas cloud-native e liderança técnica, alinhando ao perfil Staff Engineer.",
    sectionId: "summary",
  },
  {
    id: "c2",
    section: "Experiência",
    description:
      "Bullets reformulados com métricas quantificadas (40% de redução de latência, 30+ serviços monitorados). Foco em impacto sistêmico.",
    sectionId: "experience",
  },
  {
    id: "c3",
    section: "Skills",
    description:
      "Reorganizada em categorias. Go, Terraform, OpenTelemetry e BigQuery adicionados com base nos requisitos da vaga.",
    sectionId: "skills",
  },
  {
    id: "c4",
    section: "Educação",
    description: "Nenhuma alteração. Seção já estava adequada ao nível da vaga.",
    sectionId: "education",
  },
  {
    id: "c5",
    section: "Certificações",
    description: "Nenhuma alteração. Certificações existentes são relevantes para a vaga.",
    sectionId: "certifications",
  },
]

function scrollToSection(sectionId: string) {
  const el = document.getElementById(`section-${sectionId}`)
  if (el) {
    el.scrollIntoView({ behavior: "smooth", block: "center" })
    el.classList.add("ring-2", "ring-foreground/20", "ring-offset-2")
    setTimeout(() => el.classList.remove("ring-2", "ring-foreground/20", "ring-offset-2"), 2000)
  }
}

export function ChangesAppliedTab() {
  return (
    <div className="space-y-3">
      {changes.map((change, idx) => {
        const hasChange = change.description.toLowerCase().includes("nenhuma") === false
        return (
          <div
            key={change.id}
            className={cn(
              "rounded-lg border p-4 space-y-2",
              hasChange ? "border-border bg-card" : "border-border bg-secondary/40"
            )}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {hasChange ? (
                  <span className="inline-block w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0" />
                ) : (
                  <span className="inline-block w-1.5 h-1.5 rounded-full bg-border shrink-0" />
                )}
                <p className="text-sm font-semibold text-foreground">{change.section}</p>
              </div>
              {hasChange && (
                <span className="text-[11px] font-medium px-2 py-0.5 rounded-full bg-amber-50 border border-amber-200 text-amber-700">
                  alterado
                </span>
              )}
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed">{change.description}</p>
            {hasChange && (
              <button
                onClick={() => scrollToSection(change.sectionId)}
                className="inline-flex items-center gap-1.5 text-xs font-medium text-foreground hover:underline underline-offset-2 transition-colors"
              >
                <Eye className="w-3 h-3" />
                Ver no currículo
              </button>
            )}
          </div>
        )
      })}
    </div>
  )
}
