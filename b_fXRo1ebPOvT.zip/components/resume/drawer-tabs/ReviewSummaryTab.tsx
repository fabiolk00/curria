"use client"

import { CheckCircle2, Zap, Target, Tag } from "lucide-react"

const keywords = [
  "microsserviços",
  "observabilidade",
  "cloud-native",
  "Kafka",
  "Go",
  "Terraform",
  "SRE",
  "OpenTelemetry",
]

export function ReviewSummaryTab() {
  return (
    <div className="space-y-5">
      {/* Target role */}
      <div className="rounded-lg border border-border bg-secondary/50 p-4">
        <div className="flex items-start gap-3">
          <Target className="w-4 h-4 text-muted-foreground mt-0.5 shrink-0" />
          <div>
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-1">
              Vaga identificada
            </p>
            <p className="text-sm font-semibold text-foreground">Staff Software Engineer – Platform</p>
            <p className="text-xs text-muted-foreground mt-0.5">Stone Co. · São Paulo, SP</p>
          </div>
        </div>
      </div>

      {/* Status */}
      <div className="flex items-center gap-2 px-3 py-2.5 rounded-lg bg-green-50 border border-green-200">
        <CheckCircle2 className="w-4 h-4 text-green-600 shrink-0" />
        <p className="text-sm font-medium text-green-800">Currículo gerado com sucesso</p>
      </div>

      {/* Main improvements */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <Zap className="w-3.5 h-3.5 text-muted-foreground" />
          <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Principais melhorias
          </p>
        </div>
        <ul className="space-y-2.5">
          {[
            "Resumo profissional reescrito com foco em arquitetura de plataforma",
            "Experiências reposicionadas com métricas quantificadas de impacto",
            "Stack técnica expandida para incluir Go, Terraform e OpenTelemetry",
            "Palavras-chave da vaga incorporadas de forma natural no texto",
          ].map((item, i) => (
            <li key={i} className="flex items-start gap-2.5 text-sm text-foreground">
              <span className="w-4 h-4 rounded-full bg-foreground text-primary-foreground text-[10px] flex items-center justify-center font-bold shrink-0 mt-0.5">
                {i + 1}
              </span>
              {item}
            </li>
          ))}
        </ul>
      </div>

      {/* Keywords */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <Tag className="w-3.5 h-3.5 text-muted-foreground" />
          <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Keywords priorizadas
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          {keywords.map((kw) => (
            <span
              key={kw}
              className="inline-flex items-center px-2.5 py-1 rounded-md bg-secondary border border-border text-xs font-medium text-foreground"
            >
              {kw}
            </span>
          ))}
        </div>
      </div>
    </div>
  )
}
