"use client"

import { CheckCircle2, XCircle, Circle } from "lucide-react"

const coveredRequirements = [
  "6+ anos de experiência em engenharia de software",
  "Experiência com microsserviços e arquiteturas distribuídas",
  "Conhecimento de cloud (AWS ou GCP)",
  "Experiência com observabilidade e monitoramento",
  "Histórico de mentoria e liderança técnica",
]

const gaps = [
  "Experiência prévia como Staff Engineer ou Tech Lead formal",
  "Contribuições open source relevantes para a área de plataforma",
  "Experiência com on-call rotation e SLO/SLA management",
]

const keyRequirements = [
  "Arquitetura de sistemas distribuídos de alta escala",
  "Go ou Rust como linguagem principal",
  "Infra como código (Terraform, Pulumi)",
  "Cultura de engenharia orientada a plataforma (Platform Engineering)",
  "Capacidade de influenciar decisões técnicas cross-team",
]

export function JobTargetTab() {
  return (
    <div className="space-y-5">
      {/* Job summary */}
      <div className="rounded-lg border border-border bg-secondary/50 p-4 space-y-2">
        <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
          Resumo da vaga
        </p>
        <p className="text-sm font-semibold text-foreground">Staff Software Engineer – Platform</p>
        <p className="text-xs text-muted-foreground">Stone Co. · São Paulo, SP · Híbrido</p>
        <p className="text-xs text-foreground leading-relaxed mt-1">
          Buscamos uma engenheira ou engenheiro experiente para liderar iniciativas de infraestrutura 
          de plataforma, melhorar a experiência do desenvolvedor e garantir a confiabilidade dos 
          sistemas de pagamentos em escala.
        </p>
      </div>

      {/* Key requirements */}
      <div>
        <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-3">
          Requisitos principais
        </p>
        <ul className="space-y-2">
          {keyRequirements.map((req, i) => (
            <li key={i} className="flex items-start gap-2.5 text-sm text-foreground">
              <Circle className="w-3.5 h-3.5 text-border mt-0.5 shrink-0 fill-border" />
              {req}
            </li>
          ))}
        </ul>
      </div>

      {/* Covered requirements */}
      <div>
        <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-3">
          Requisitos atendidos
        </p>
        <ul className="space-y-2">
          {coveredRequirements.map((req, i) => (
            <li key={i} className="flex items-start gap-2.5 text-sm text-foreground">
              <CheckCircle2 className="w-3.5 h-3.5 text-green-600 mt-0.5 shrink-0" />
              {req}
            </li>
          ))}
        </ul>
      </div>

      {/* Gaps */}
      <div>
        <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-1">
          Lacunas identificadas
        </p>
        <p className="text-xs text-muted-foreground mb-3">
          Não foram adicionados ao currículo por não haver base no currículo original.
        </p>
        <ul className="space-y-2">
          {gaps.map((gap, i) => (
            <li key={i} className="flex items-start gap-2.5 text-sm text-muted-foreground">
              <XCircle className="w-3.5 h-3.5 text-muted-foreground/60 mt-0.5 shrink-0" />
              {gap}
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}
