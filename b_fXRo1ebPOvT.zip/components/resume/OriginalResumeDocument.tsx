import { FileText } from "lucide-react"
import { Separator } from "@/components/ui/separator"
import type { ResumeData } from "./types"

interface OriginalResumeDocumentProps {
  data: ResumeData
}

export function OriginalResumeDocument({ data }: OriginalResumeDocumentProps) {
  return (
    <div className="flex flex-col gap-3">
      {/* Column label */}
      <div className="flex items-center gap-1.5">
        <FileText className="size-3.5 text-zinc-400" />
        <span className="text-sm font-medium text-zinc-500">
          Currículo original
        </span>
      </div>

      {/* Document card */}
      <div className="bg-white border border-zinc-200 rounded-lg overflow-hidden opacity-80">
        <div className="p-6 sm:p-8 space-y-6 font-sans">
          {/* Candidate name */}
          <div>
            <h1 className="text-xl font-semibold text-zinc-700 leading-tight">
              {data.candidateName}
            </h1>
          </div>

          <Separator className="bg-zinc-100" />

          {/* Sections */}
          <div className="space-y-6">
            {data.sections.map((section) => (
              <div key={section.id} className="space-y-1.5">
                <h2 className="text-xs font-semibold uppercase tracking-wide text-zinc-400">
                  {section.title}
                </h2>
                <div className="text-sm text-zinc-600 leading-relaxed whitespace-pre-line">
                  {section.content}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
