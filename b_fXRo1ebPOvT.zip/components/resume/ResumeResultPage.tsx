"use client"

import { ResultHeader } from "./ResultHeader"
import { AttentionBanner } from "./AttentionBanner"
import { ResumeDocument } from "./ResumeDocument"
import { OriginalResumeDocument } from "./OriginalResumeDocument"
import { ReviewSidebar } from "./ReviewSidebar"
import { mockJobTargetingData } from "./mock-data"
import type { ResumeResultData } from "./types"

// ─── Main layout ─────────────────────────────────────────────────────────────

function ResumeResultLayout({ data }: { data: ResumeResultData }) {
  const isAtsWithComparison =
    data.flow === "ats-enhancement" && !!data.original
  const hasSidebar =
    data.attentionPoints.length > 0 || data.adherenceSuggestions.length > 0

  const label =
    data.flow === "job-targeting"
      ? "Currículo adaptado para a vaga"
      : "Currículo otimizado"

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
      {isAtsWithComparison ? (
        /* ATS Enhancement: original left, optimized right, optional sidebar */
        <div
          className={`grid gap-6 ${
            hasSidebar
              ? "lg:grid-cols-[1fr_1fr_300px]"
              : "lg:grid-cols-[1fr_1fr]"
          }`}
        >
          <OriginalResumeDocument data={data.original!} />

          <ResumeDocument
            data={data.generated}
            label="Currículo otimizado"
            isLocked={data.isPreviewLocked}
            onEdit={() => {}}
          />

          {hasSidebar && (
            <div className="lg:pt-8">
              <ReviewSidebar
                attentionPoints={data.attentionPoints}
                adherenceSuggestions={data.adherenceSuggestions}
              />
            </div>
          )}
        </div>
      ) : (
        /* Job Targeting (or ATS without original): generated as main focus */
        <div
          className={`grid gap-6 ${
            hasSidebar
              ? "lg:grid-cols-[1fr_300px]"
              : "max-w-3xl mx-auto"
          }`}
        >
          <ResumeDocument
            data={data.generated}
            label={label}
            isLocked={data.isPreviewLocked}
            onEdit={() => {}}
          />

          {hasSidebar && (
            <div className="lg:pt-8">
              <ReviewSidebar
                attentionPoints={data.attentionPoints}
                adherenceSuggestions={data.adherenceSuggestions}
              />
            </div>
          )}
        </div>
      )}
    </div>
  )
}

// ─── Page root ───────────────────────────────────────────────────────────────

export function ResumeResultPage() {
  const data: ResumeResultData = mockJobTargetingData

  return (
    <div className="min-h-screen bg-zinc-50 flex flex-col">
      <ResultHeader
        flow={data.flow}
        jobTitle={data.generated.jobTitle}
        companyName={data.generated.companyName}
        isDownloadAvailable={data.isDownloadAvailable}
        isDownloadLoading={data.isDownloadLoading}
        isPreviewLocked={data.isPreviewLocked}
        onBack={() => {}}
        onDownload={() => {}}
      />

      <AttentionBanner count={data.attentionPoints.length} />

      <main className="flex-1">
        <ResumeResultLayout data={data} />
      </main>
    </div>
  )
}
