"use client"

import { useState } from "react"
import { ChevronRight, ChevronLeft, Sparkles } from "lucide-react"
import { cn } from "@/lib/utils"
import { ReviewSummaryTab } from "./drawer-tabs/ReviewSummaryTab"
import { AttentionPointsTab } from "./drawer-tabs/AttentionPointsTab"
import { ChangesAppliedTab } from "./drawer-tabs/ChangesAppliedTab"
import { JobTargetTab } from "./drawer-tabs/JobTargetTab"

type DrawerTab = "resumo" | "atencao" | "mudancas" | "vaga"

const tabs: { id: DrawerTab; label: string; badgeCount?: number }[] = [
  { id: "resumo", label: "Resumo" },
  { id: "atencao", label: "Atenção", badgeCount: 4 },
  { id: "mudancas", label: "Mudanças", badgeCount: 3 },
  { id: "vaga", label: "Vaga" },
]

interface AiReviewDrawerProps {
  isOpen: boolean
  onToggle: () => void
}

export function AiReviewDrawer({ isOpen, onToggle }: AiReviewDrawerProps) {
  const [activeTab, setActiveTab] = useState<DrawerTab>("resumo")

  return (
    <>
      {/* Backdrop on mobile */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-foreground/20 z-30 md:hidden"
          onClick={onToggle}
        />
      )}

      {/* Floating toggle tab — visible on desktop only */}
      <button
        onClick={onToggle}
        aria-label={isOpen ? "Fechar revisão da IA" : "Abrir revisão da IA"}
        className={cn(
          "hidden md:flex fixed top-1/2 -translate-y-1/2 z-40 items-center gap-2",
          "bg-foreground text-primary-foreground rounded-l-lg px-2 py-4 shadow-lg",
          "transition-all duration-300 hover:bg-foreground/80",
          isOpen ? "right-[400px]" : "right-0"
        )}
        style={{ writingMode: "vertical-rl", textOrientation: "mixed" }}
      >
        <div className="flex items-center gap-1.5" style={{ writingMode: "horizontal-tb" }}>
          {isOpen ? (
            <ChevronRight className="w-3.5 h-3.5 shrink-0" />
          ) : (
            <ChevronLeft className="w-3.5 h-3.5 shrink-0" />
          )}
        </div>
        <span className="text-[11px] font-semibold tracking-wider uppercase">
          Revisão da IA
        </span>
      </button>

      {/* Drawer panel */}
      <aside
        className={cn(
          "fixed right-0 top-0 h-full z-40 bg-card border-l border-border shadow-xl",
          "flex flex-col transition-transform duration-300 ease-in-out",
          // Desktop: slide from right, 400px wide
          "md:w-[400px]",
          // Mobile: full-screen bottom sheet effect
          "w-full",
          isOpen ? "translate-x-0" : "translate-x-full"
        )}
      >
        {/* Drawer header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-border shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-foreground flex items-center justify-center">
              <Sparkles className="w-3.5 h-3.5 text-primary-foreground" />
            </div>
            <div>
              <p className="text-sm font-semibold text-foreground">Revisão da IA</p>
              <p className="text-xs text-muted-foreground">Análise do currículo gerado</p>
            </div>
          </div>
          <button
            onClick={onToggle}
            className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-secondary transition-colors text-muted-foreground hover:text-foreground"
            aria-label="Fechar painel"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-border shrink-0 px-1">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={cn(
                "relative flex items-center gap-1.5 px-3 py-3 text-xs font-medium transition-colors",
                activeTab === tab.id
                  ? "text-foreground border-b-2 border-foreground -mb-px"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {tab.label}
              {tab.badgeCount && (
                <span
                  className={cn(
                    "inline-flex items-center justify-center w-4 h-4 rounded-full text-[10px] font-bold",
                    activeTab === tab.id
                      ? "bg-foreground text-primary-foreground"
                      : "bg-secondary text-muted-foreground"
                  )}
                >
                  {tab.badgeCount}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Tab content */}
        <div className="flex-1 overflow-y-auto p-5">
          {activeTab === "resumo" && <ReviewSummaryTab />}
          {activeTab === "atencao" && <AttentionPointsTab />}
          {activeTab === "mudancas" && <ChangesAppliedTab />}
          {activeTab === "vaga" && <JobTargetTab />}
        </div>
      </aside>
    </>
  )
}
