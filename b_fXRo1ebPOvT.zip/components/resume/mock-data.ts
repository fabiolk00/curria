import type { ResumeResultData } from "./types"

export const mockJobTargetingData: ResumeResultData = {
  flow: "job-targeting",
  isPreviewLocked: false,
  isDownloadAvailable: true,
  isDownloadLoading: false,
  generated: {
    candidateName: "Mariana Costa",
    jobTitle: "Gerente de Controladoria",
    companyName: "Grupo Vértice",
    sections: [
      {
        id: "summary",
        title: "Resumo Profissional",
        isHighlighted: true,
        content:
          "Profissional com 9 anos de experiência em controladoria e planejamento financeiro em empresas de médio e grande porte. Histórico comprovado em fechamento mensal, análise de desvios e reporte ao board. Experiência com ERP SAP e forte atuação em projetos de reestruturação financeira.",
      },
      {
        id: "experience",
        title: "Experiência Profissional",
        content:
          "Controladoria Sênior — Construtora Metron (2019–2024)\n• Responsável pelo fechamento contábil e gerencial mensal de 4 unidades de negócio\n• Implantação de processo de forecast rolling com redução de 40% no tempo de consolidação\n• Reporte direto ao CFO com análise de P&L, capex e desvios orçamentários\n\nAnalista de Controladoria — Grupo Altria (2015–2019)\n• Apoio no processo de budget e acompanhamento de KPIs financeiros\n• Responsável pela conciliação de contas a pagar e receber",
      },
      {
        id: "education",
        title: "Formação",
        content:
          "MBA em Finanças Corporativas — FIA Business School (2020)\nGraduação em Ciências Contábeis — Universidade Mackenzie (2014)",
      },
      {
        id: "skills",
        title: "Competências",
        isHighlighted: true,
        content:
          "SAP FI/CO · Power BI · Excel avançado · Forecast rolling · Budget · P&L · Análise de desvios · Reporte executivo",
      },
    ],
  },
  scoreBreakdown: {
    total: 93,
    maxTotal: 100,
    items: [
      { label: "Hard Skills", score: 37, max: 40 },
      { label: "Experiência", score: 29, max: 30 },
      { label: "Palavras-chave", score: 19, max: 20 },
      { label: "Formação", score: 8, max: 10 },
    ],
    criticalGaps: [
      "Ausência de menção explícita a 'Testes Unitários' dentro das boas práticas de código.",
      "Familiaridade com serviços específicos da AWS (Lambda, EC2) não detalhada, embora AWS em geral seja mencionada.",
    ],
  },
  attentionPoints: [
    {
      id: "ap1",
      severity: "warning",
      title: "Indicadores de margem não explicitados",
      description:
        "A experiência com P&L está mencionada, mas não há número concreto de margem ou faturamento gerenciado.",
      detail:
        'Adicione algo como: "gestão de P&L de R$ 120M, com margem EBITDA de 18%".',
    },
    {
      id: "ap2",
      severity: "review",
      title: "Período de gap entre 2014 e 2015",
      description:
        "Há um intervalo de um ano entre a graduação e o primeiro emprego. Não é problemático, mas pode ser questionado.",
    },
    {
      id: "ap3",
      severity: "error",
      title: "Certificação CRC não mencionada",
      description:
        "A vaga exige CRC ativo. Inclua o número do registro se possuir.",
    },
  ],
  adherenceSuggestions: [
    {
      id: "s1",
      priority: "Alta",
      title: "P&L, margem e forecast",
      description:
        "Ainda não há evidência clara de gestão de margem e faturamento. Inclua apenas se fizer parte da sua experiência real.",
      example:
        'Exemplo: "Gestão de P&L de R$ 80M com controle de margem e ciclo de forecast mensal."',
    },
    {
      id: "s2",
      priority: "Alta",
      title: "Experiência com budget de capex",
      description:
        "A vaga menciona budget de capex como requisito. Traga evidência se tiver atuado nessa frente.",
      example: 'Exemplo: "Acompanhamento de budget de capex de R$ 12M por ano."',
    },
    {
      id: "s3",
      priority: "Média",
      title: "Liderança de equipe",
      description:
        "A posição inclui gestão de analistas. Mencione o tamanho do time se tiver liderado pessoas.",
      example: 'Exemplo: "Liderança de equipe de 3 analistas de controladoria."',
    },
    {
      id: "s4",
      priority: "Baixa",
      title: "IFRS ou CPC aplicado",
      description:
        "Diferencial mencionado no descritivo. Adicione se tiver experiência com normas internacionais.",
    },
  ],
}

export const mockAtsEnhancementData: ResumeResultData = {
  flow: "ats-enhancement",
  isPreviewLocked: false,
  isDownloadAvailable: true,
  isDownloadLoading: false,
  generated: {
    candidateName: "Mariana Costa",
    sections: [
      {
        id: "summary",
        title: "Resumo Profissional",
        isHighlighted: true,
        content:
          "Profissional com 9 anos de experiência em controladoria e planejamento financeiro. Histórico comprovado em fechamento mensal, análise de desvios e reporte ao board. Experiência com ERP SAP.",
      },
      {
        id: "experience",
        title: "Experiência Profissional",
        content:
          "Controladoria Sênior — Construtora Metron (2019–2024)\n• Fechamento contábil mensal de 4 unidades de negócio\n• Implantação de processo de forecast rolling\n• Reporte direto ao CFO\n\nAnalista de Controladoria — Grupo Altria (2015–2019)\n• Apoio no processo de budget e acompanhamento de KPIs financeiros",
      },
      {
        id: "education",
        title: "Formação",
        content:
          "MBA em Finanças Corporativas — FIA Business School (2020)\nGraduação em Ciências Contábeis — Universidade Mackenzie (2014)",
      },
      {
        id: "skills",
        title: "Competências",
        isHighlighted: true,
        content: "SAP FI/CO · Power BI · Excel avançado · Budget · P&L",
      },
    ],
  },
  original: {
    candidateName: "Mariana Costa",
    sections: [
      {
        id: "summary",
        title: "Resumo Profissional",
        content:
          "Tenho experiência na área de controladoria e finanças há quase 10 anos. Trabalhei em empresas de construção civil e varejo. Gosto de trabalhar com números e análise de dados.",
      },
      {
        id: "experience",
        title: "Experiência",
        content:
          "Construtora Metron (2019–2024) — Controladoria\nGrupo Altria (2015–2019) — Financeiro",
      },
      {
        id: "education",
        title: "Educação",
        content:
          "MBA em Finanças — FIA (2020)\nCiências Contábeis — Mackenzie (2014)",
      },
      {
        id: "skills",
        title: "Habilidades",
        content: "SAP, Excel, Power BI",
      },
    ],
  },
  attentionPoints: [
    {
      id: "ap1",
      severity: "review",
      title: "Verbos de ação não padronizados",
      description:
        "Algumas bullets ainda usam substantivos em vez de verbos de ação. Revisar antes de enviar.",
    },
  ],
  adherenceSuggestions: [],
}
