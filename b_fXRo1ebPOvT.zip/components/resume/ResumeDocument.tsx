"use client"

import { CheckCircle, Pencil, Lock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { cn } from "@/lib/utils"
import type { ResumeData } from "./types"

interface ResumeDocumentProps {
  data: ResumeData
  label?: string
  isLocked?: boolean
  onEdit?: () => void
}

export function ResumeDocument({
  data,
  label = "Currículo gerado",
  isLocked = false,
  onEdit,
}: ResumeDocumentProps) {
  return (
    <div className="flex flex-col gap-3">
      {/* Column label */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <CheckCircle className="size-3.5 text-emerald-600" />
          <span className="text-sm font-medium text-zinc-700">{label}</span>
        </div>
        {onEdit && !isLocked && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onEdit}
            className="gap-1.5 text-zinc-500 hover:text-zinc-900 h-7 px-2"
            aria-label="Editar currículo"
          >
            <Pencil className="size-3.5" />
            <span className="text-xs">Editar</span>
          </Button>
        )}
      </div>

      {/* Document card */}
      <div
        className={cn(
          "bg-white border border-zinc-200 rounded-lg overflow-hidden",
          isLocked && "relative",
        )}
      >
        {/* Locked overlay */}
        {isLocked && (
          <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-white/80 backdrop-blur-sm rounded-lg">
            <div className="flex flex-col items-center gap-3 text-center p-6">
              <div className="size-10 rounded-full bg-zinc-100 flex items-center justify-center">
                <Lock className="size-4 text-zinc-500" />
              </div>
              <div>
                <p className="text-sm font-medium text-zinc-900">
                  Visualização bloqueada
                </p>
                <p className="text-xs text-zinc-500 mt-0.5">
                  Faça upgrade para visualizar e baixar o currículo completo.
                </p>
              </div>
              <Button size="sm" className="mt-1">
                Ver planos
              </Button>
            </div>
          </div>
        )}

        {/* Document content */}
        <div className="p-6 sm:p-8 space-y-6 font-sans">
          {/* Candidate name */}
          <div>
            <h1 className="text-xl font-semibold text-zinc-900 leading-tight">
              {data.candidateName}
            </h1>
            {data.jobTitle && data.companyName && (
              <p className="text-sm text-zinc-500 mt-0.5">
                Candidatura: {data.jobTitle} · {data.companyName}
              </p>
            )}
          </div>

          <Separator className="bg-zinc-100" />

          {/* Sections */}
          <div className="space-y-6">
            {data.sections.map((section) => (
              <div
                key={section.id}
                className={cn(
                  "space-y-1.5 rounded-md transition-colors",
                  section.isHighlighted &&
                    "bg-amber-50 border border-amber-100 p-3 -mx-3",
                )}
              >
                <div className="flex items-center gap-2">
                  <h2 className="text-xs font-semibold uppercase tracking-wide text-zinc-400">
                    {section.title}
                  </h2>
                  {section.isHighlighted && (
                    <span className="text-xs text-amber-600 font-medium">
                      editado
                    </span>
                  )}
                </div>
                <div className="text-sm text-zinc-800 leading-relaxed whitespace-pre-line">
                  {section.content}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
